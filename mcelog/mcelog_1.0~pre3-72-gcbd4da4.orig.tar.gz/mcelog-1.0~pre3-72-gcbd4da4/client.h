void ask_server(char *command);
