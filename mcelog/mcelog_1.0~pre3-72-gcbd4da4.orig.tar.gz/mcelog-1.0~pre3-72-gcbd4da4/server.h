void server_setup(void);
