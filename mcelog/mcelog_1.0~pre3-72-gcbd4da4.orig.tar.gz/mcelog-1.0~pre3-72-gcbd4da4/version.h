#define MCELOG_VERSION "1.0pre"

