void snb_decode_model(int cputype, int bank, u64 status, u64 misc);
void sandy_bridge_ep_memerr_misc(struct mce *m, int *channel, int *dimm);
