int need_stdout(void);
void flushlog(void);
void reopenlog(void);
/* others are in mcelog.h */
