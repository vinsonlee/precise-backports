void xeon75xx_memory_error(struct mce *m, unsigned msize, int *channel, int *dimm);
void xeon75xx_decode_dimm(struct mce *m, unsigned msize);
