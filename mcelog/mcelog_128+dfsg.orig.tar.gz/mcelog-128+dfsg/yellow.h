void yellow_setup(void);
void run_yellow_trigger(int cpu, int tnum, int lnum, char *ts, char *ls, int socket);
